import os
from dotenv import load_dotenv
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler
import bot as bot

# Importamos las variables de entorno. En este caso el TOKEN.
load_dotenv()
TOKEN = "2138360025:AAFTVw5WBTguVBYx1ncx6j89QAGZW78V4M4"


def main():
    #Establecemos una conexión entre nuestro programa y el Bot que creamos.
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher # Despachador de solicitudes.

    #Establecer los comandos que escuche el Bot.
    dp.add_handler(CommandHandler("iniciar", bot.iniciar))
    dp.add_handler(CommandHandler("ayuda", bot.ayuda))
    dp.add_handler(CommandHandler("saludo", bot.saludo))
    dp.add_handler(CommandHandler("polinomio", bot.polinomio))
    dp.add_handler(CommandHandler("recurrencia", bot.recurrencia))
    dp.add_handler(CommandHandler("markov", bot.markov))
    dp.add_handler(CommandHandler("grafo", bot.grafo))
    #Manejar los Callback que genera cada botón del menú de ayudas.
    dp.add_handler(CallbackQueryHandler(bot.menu_ayuda, pattern="m1")) #saludo
    dp.add_handler(CallbackQueryHandler(bot.menu_ayuda, pattern="m2")) #polinomio
    dp.add_handler(CallbackQueryHandler(bot.menu_ayuda, pattern="m3")) #recurrencia
    dp.add_handler(CallbackQueryHandler(bot.menu_ayuda, pattern="m4")) #markov
    dp.add_handler(CallbackQueryHandler(bot.menu_ayuda, pattern="m5")) #grafo

    #Iniciar el Bot.
    updater.start_polling()
    #Mantener el bot ejecutándose hasta que ocurra alguna interrupción.
    updater.idle()


if __name__ == '__main__':
    main()