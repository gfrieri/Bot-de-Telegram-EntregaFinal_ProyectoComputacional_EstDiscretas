import logging
from telegram import InlineKeyboardMarkup, InlineKeyboardButton
import sys
from io import StringIO
import matlab.engine
from bs4 import BeautifulSoup
import requests
import re
import string
import random
import networkx as nx
import matplotlib.pyplot as plt
from random import choice

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def iniciar(update, context):
    logger.info("El usuario ha iniciado el bot.")
    name = update.message.chat["first_name"]
    update.message.reply_text(f"¡Gurenyuu y bienvenid@ {name}! Es un gusto tenerte aquí :3")

    imgsaludo = open("Entrega Final Bot Telegram/src/images/greeting.png", "rb")
    id = update.message.chat.id
    update.message.bot.sendPhoto(chat_id=id, photo=imgsaludo)
    logger.info("Saludo enviado.")

    update.message.reply_text(f"Utiliza el comando /ayuda para saber qué puedo hacer :3")

def saludo(query, update):
    name = query.message.chat.first_name
    logger.info(f"El usuario {name} ha solicitado un saludo.")
    query.message.reply_text(f"¡Hola {name}! :3", parse_mode="HTML")
    logger.info("Saludo enviado.")

def ayuda(update, context):
    logger.info("El usuario ha solicitado ayuda.")
    options = [
        [InlineKeyboardButton("Saludo", callback_data="m1")],
        [InlineKeyboardButton("Polinomio", callback_data="m2")],
        [InlineKeyboardButton("Recurrencia", callback_data="m3")],
        [InlineKeyboardButton("Markov", callback_data="m4")],
        [InlineKeyboardButton("Grafo", callback_data="m5")]
        ]
    reply_markup = InlineKeyboardMarkup(options)
    update.message.reply_text("Usted ha solicitado ayuda :3", reply_markup=reply_markup)

#00 Clases y funciones utilizadas en el 01 y 02. NO TOCAR

def crearfun(script, nombre):
            with open(f"{nombre}.m","w+") as f:
                f.write(script)

class Capturing(list):
            def __enter__(self):
                self._stdout = sys.stdout
                sys.stdout = self._stringio = StringIO()
                return self
            def __exit__(self, *args):
                self.extend(self._stringio.getvalue().splitlines())
                del self._stringio
                sys.stdout = self._stdout

#01 Polinomio ----------
def polinomio(update, context):
    name = update.message.chat.first_name
    logger.info(f"El usuario {name} enviará los coeficientes del polinomio característico")
    datos = update.message.text
    datos = datos.replace("/polinomio", "").strip()
    lista = datos.split(",")
    relacionRecurencia = lista[0]
    casosIniciales = lista[1]
    try:
        eng = matlab.engine.start_matlab()
        
        script = f"""function res=solucion()
        %% Datos de Entrada
        clc;clear; syms n;syms c0;syms c1;
        RR={relacionRecurencia}
        a={casosIniciales}
        %% Proceso
        R=roots(RR);
        k=length(a);
        MR=zeros(k);
        for cont=1:k
            MR(cont,:)=R.^(cont-1);
        end
        b=[c1;c0];

        sol=dot(b,R.^n);
        %% Información de Salida
        sol
        res = ['[', strjoin(arrayfun(@char,sol,'uniform',0), ', '), ']'];
        end
                """
        crearfun(script, "solucion")

        with Capturing() as output:
            eng.solucion(nargout=1, stdout=sys.stdout) 
        update.message.reply_text("Este es el resultado:")
        update.message.reply_text("\n".join(output))
    except Exception as e:
        print(e)
        logger.info("Ha ocurrido un error enviando la secuencia.")
        update.message.reply_text("Lo sentimos, ha ocurrido un error. Por favor ingrese nuevamente los parámetros.\n\nRecuerde ingresar los parámetros según los ejemplos en la sección de /ayuda.")

def help_polinomio(query):
    name = query.message.chat.first_name
    logger.info(f"El usuario {name} ha solicitado información de la función Polinomio.")
    info = f"""
¡Bienvenido, {name}\! Para el correcto funcionamienteo de la función Polinomio debes escribir el comando "/polinomio" seguido de la relación de recurrencia y los casos iniciales\.

*Ejemplos:*
1\. /polinomio \[1; 2; 2\], \[1; 1\] 
2\. /polinomio \[1; \-1; \-2\], \[1; 1\]
3\. /polinomio \[4; 2; 0\], \[6; 9\]
4\. /polinomio \[1; 8; 9\], \[0; 1\]

Una vez ingresados los valores se enviará el resultado a través del chat\.
    """
    query.message.reply_text(info, parse_mode="MarkdownV2")

#02 Recurrencia ----------
def recurrencia(update, context):
    name = update.message.chat.first_name
    logger.info(f"El usuario {name} enviará los coeficientes del polinomio característico con el valor de la constante")
    datos = update.message.text
    datos = datos.replace("/recurrencia", "").strip()
    lista = datos.split(",")
    relacionRecurencia = lista[0]
    casosIniciales = lista[1]
    primeraIteracion = lista[2]
    try:
        eng = matlab.engine.start_matlab()

        script = f"""function sol=solucionRec()
        %% Datos de Entrada
        clc;clear all;syms n;
        RR={relacionRecurencia}
        a={casosIniciales}
        i0={primeraIteracion}
        %% Proceso
        R=roots(RR);
        k=length(a);
        MR=zeros(k);
        for cont=1:k
            MR(cont,:)=R.^(i0+cont-1);
        end
        b=MR\\a;

        sol=dot(b,R.^n);
        %% Información de Salida
        sol
        end
                """
        crearfun(script, "solucionRec")
        
        with Capturing() as output:
            eng.solucionRec(nargout=1, stdout=sys.stdout)
        update.message.reply_text("Este es el resultado:") 
        update.message.reply_text("\n".join(output))
    except Exception as e:
        logger.info("Ha ocurrido un error generando la secuencia.")
        update.message.reply_text("Lo sentimos, ha ocurrido un error. Por favor ingrese nuevamente los parámetros.\n\nRecuerde ingresar los parámetros según los ejemplos en la sección de /ayuda.")
        print(e)

def help_recurrencia(query):
    name = query.message.chat.first_name
    logger.info(f"El usuario {name} ha solicitado información de la función Recurrencia.")
    info = f"""
¡Bienvenido, {name}\! Para el correcto funcionamienteo de la función Recurrencia debes escribir el comando "/recurrencia" seguido de la relación de recurrencia, los casos iniciales y el valor constante\.

*Ejemplos:*
1\. /recurrencia \[1; 2; 2\], \[1; 1\], 0
2\. /recurrencia \[1; 2; 2\], \[1; 1\], 1 
3\. /recurrencia \[1; \-1; \-2\], \[1; 1\], 0
4\. /recurrencia \[1; \-1; \-2\], \[1; 1\], 1


Una vez ingresados los valores se enviará el resultado a través del chat\.
    """
    query.message.reply_text(info, parse_mode="MarkdownV2")


#03 Markov ----------
def markov(update, context):
    name = update.message.chat.first_name
    logger.info(f"El usuario {name} generará un texto al azar del enlace de un sitio web estático")
    url = update.message.text
    url = url.replace("/markov", "").strip()
    print(url)
    try:
        #Establece conexión con el sitio web estático dado por el usuario
        response = requests.get(url)
        soup = BeautifulSoup(response.content, "html.parser")

        #Almacena el contenido que sea en formato de texto del sitio web
        contenido = soup.html
        texto = []
        for string in contenido.strings:
            texto.append(string)

        #Convierte la lista con el texto en string
        texto = str(texto)

        #Limpia el texto por salto de línea, puntuación, números y espacios extra respectivamente
        def limpiar_texto(text: str):
            text = re.sub(r"\\n", "", text)
            text = re.sub(r'[^\w\s]', '', text)
            text = re.sub(r'[0-9]+', '', text)
            text = re.sub(' +', ' ', text)
            return text

        #Se ejecuta la función para limpiar el texto
        texto = limpiar_texto(texto)
        print(texto)

        #Se guarda el texto original para enviarlo en forma de .txt
        with open("Entrega Final Bot Telegram/src/docs/texto.txt", "w", encoding="utf-8") as archivo:
                archivo.write(texto)

        update.message.reply_text(f"Este es el texto recopilado del sitio web dado:", parse_mode="MarkdownV2")
        txt = open("Entrega Final Bot Telegram/src/docs/texto.txt", "rb")
        chat_id = update.message.chat.id
        update.message.bot.sendDocument(chat_id=chat_id, document=txt, timeout=300)

        #Convierte el texto en lista para el conteo de letras
        letras = list(texto)
        dic = {}
        for letra in letras:
            if letra not in dic.keys():
                dic[letra] = 1
            else:
                dic[letra] += 1

        #Se obtiene la frecuencia absoluta de las letras
        freqa = 0
        for llave in dic.keys():
            freq = dic[llave]/len(letras)
            freqa += freq
            dic[llave] = [freqa]

        #Ejecuta el procedimiento de las cadenas de Markov para randomizar el texto
        def markov():
            #Se almacena en una lista cada frecuencia acumulada
            frecuencias = []
            for llaves in dic.keys():
                faq = float(str(dic.get(llaves)).replace("[", "").replace("]", ""))
                frecuencias.append(faq)

            #Se cambia cada letra y se almacena en una nueva lista
            final = []
            for recorrido in letras:
                ranNum = random.random()
                prob = min(frecuencias, key=lambda x:abs(x-ranNum))
                for cadena in dic.keys():
                    if prob == float(str(dic.get(cadena)).replace("[", "").replace("]", "")):
                        final.append(str(cadena))

            final = (limpiar_texto(str(final))).replace(" ", "")
            print("Markov: ", final)

            #Se guarda el texto resultante para enviarlo en forma de .txt
            with open("Entrega Final Bot Telegram/src/docs/markov.txt", "w", encoding="utf-8") as archivo:
                archivo.write(final)

            update.message.reply_text(f"Este es el texto resultado luego de aplicar Markov K \= 0:", parse_mode="MarkdownV2")
            txt = open("Entrega Final Bot Telegram/src/docs/markov.txt", "rb")
            chat_id = update.message.chat.id
            update.message.bot.sendDocument(chat_id=chat_id, document=txt, timeout=300)

        markov()
    except Exception as e:
        logger.info("Ha ocurrido un error generando el texto")
        update.message.reply_text("Lo sentimos, ha ocurrido un error.\nPor favor ingrese de nuevo el comando seguido del enclace. \n\nRecuerde que debe ser el enlace de un sitio web estático")
        print(e)

def help_markov(query):
    name = query.message.chat.first_name
    logger.info(f"El usuario {name} ha solicitado información de la función Markov.")
    info = f"""
¡Bienvenido, {name}\! Para el correcto funcionamienteo de la función Markov debes escribir el comando "/markov" seguido del enlace a un sitio web estático\.

*Ejemplo:*
1\. /markov http://milk\.com/
2\. /markov https://reverent\-minsky\-e02c78\.netlify\.app/
3\. /markov https://es\.wikipedia\.org/wiki/Página\_web\_estática
4\. /markov https://es\.wikipedia\.org/wiki/Cadena\_de\_Márkov
5\. /markov https://nomadlist\.com/

Una vez ingresado el enlace se recopilará todo el texto contenido en este y se devolverá un texto al azar con base a la probabilidad de aparición de los carácteres presentes\.
    """
    query.message.reply_text(info, parse_mode="MarkdownV2")

#04 Grafo ----------
def grafo(update, context):
    name = update.message.chat.first_name
    logger.info(f"El usuario {name} generará un grafo")
    datos = update.message.text
    datos = datos.replace("/grafo", "").strip()
    lista = eval(datos)
    V = lista[0]
    A = lista[1]
    K = lista [2]
    try:
        #Inicia el grafo 
        #V: Número de vértices (puntos)
        #A: Número de aristas (líneas)
        #K: Máximo de aristas por vértice
        grafo = []
        grafNodos = []
        for nodo in range(1, V):
            grafNodos.append(nodo)

        peso = [0] * V
        aristas = [[None] * K for i in range(V)]

        #Almacena los vértices con los datos del usuario
        def almacenar_vertice(grafo, punto1, punto2, peso, aristas):
            grafo.append((punto1, punto2))
            peso[punto1] += 1
            peso[punto2] += 1
            aristas[punto1].append(punto2)

        #Ejecuta la función para almacenar los vértices hasta llegar al número de aristas
        while A > 0:
            for i in range(V):
                if (peso[i] < K):
                    random = choice([x for x in range(0, V) if peso[x] < K and i not in aristas[x] and i != x])
                    almacenar_vertice(grafo, i, random, peso, aristas)
                else:
                    random1 = choice([x for x in range(0, V) if peso[x] < K])
                    random2 = choice([x for x in range(0, V) if peso[x] < K and random1 not in aristas[x] and i != x])
                    almacenar_vertice(grafo, random1, random2, peso, aristas)
                A -= 1
                if A == 0:
                    break
            if A == 0:
                break
        
        def dibujar_grafo(nodos, grafo):
            #Extrae los nodos y crea un grafo utilizando NetworkX 
            grafNodos = set(nodos)
            elGrafo=nx.Graph()

            #Añade los nodos y las aristas al grafo
            for nodo in grafNodos:
                elGrafo.add_node(nodo)
            for edge in grafo:
                elGrafo.add_edge(edge[0], edge[1])

            #Dibuja el grafo e imprime el grafo
            posicion = nx.shell_layout(elGrafo)
            nx.draw(elGrafo, posicion, node_color="#824f78", edgecolors="#000000", edge_color="#000000")
            plt.savefig("Entrega Final Bot Telegram/src/images/grafo.png")
            plt.close()

        dibujar_grafo(grafNodos, grafo)
        graf = open("Entrega Final Bot Telegram/src/images/grafo.png", "rb")
        update.message.reply_text("Este es el grafo solicitado:")
        id = update.message.chat.id
        update.message.bot.sendPhoto(chat_id=id, photo=graf)
        
    except Exception as e:
        logger.info("Ha ocurrido un error generando el grafo")
        update.message.reply_text("Lo sentimos, ha ocurrido un error.\nPor favor ingrese el número de áristas, vertices y el peso del grafo.\n\nRecuerde ingresar valores correspondientes a un grafo posible.")
        print(e)

def help_grafo(query):
    name = query.message.chat.first_name
    logger.info(f"El usuario {name} ha solicitado información de la función Grafo.")
    info = f"""
¡Bienvenido, {name}\! Para el correcto funcionamienteo de la función Grafo debes escribir el comando "/grafo" seguido de tres números separados por ","\.
Estos tres números corresponden a los vértices, aristas y peso del grafo respectivamente\.

*Ejemplos:*
1\. /grafo 9, 8, 4
2\. /grafo 2, 1, 1
3\. /grafo 5, 3, 2
4\. /grafo 100, 100, 100

Una vez ingresado los datos se generará el grafo y se enviará en formato png a través del chat\.
Recuerde ingresar valores que permitan generar grafos posibles, de lo contrario no se podrá gráficar ningún grafo\.
    """
    query.message.reply_text(info, parse_mode="MarkdownV2")


#Menú de ayuda ----------
def menu_ayuda(update, context):
    query = update.callback_query
    query.answer()
    callback = query.data
    if callback == "m1":
        saludo(query, update)
    elif callback == "m2":
        help_polinomio(query)
    elif callback == "m3":
        help_recurrencia(query)
    elif callback == "m4":
        help_markov(query)
    else:
        help_grafo(query)